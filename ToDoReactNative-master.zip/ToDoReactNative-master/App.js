import React, {Component} from 'react';
import {StyleSheet, Text, View, Button} from 'react-native';


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'grey',
  },
  welcome: {
    fontSize: 25,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
    fontSize: 30,
  },
});


class CountEvenNumbers extends Component {
  shouldComponentUpdate(nextProps) {
    
    return !(nextProps.count % 2);
  }

  componentDidUpdate(){
    console.log (this.props.count)
  }
  
  render(){
    return ( 
      <Text style={styles.instructions}>{this.props.count}</Text>
    );  
  }
}

 class Counter extends Component{
  constructor (){
    super ()
    this.state ={
      count :0,
    }
  }

  componentDidMount(){
    this.interval = setInterval (this.increment,1000)
  }

  componentWillUnmount(){
    clearInterval(this.interval)
  }

  increment = ()  => {
    this.setState(prevState => ({ count:prevState.count +1}))
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.welcome}>To do Application, welcome.</Text>
        <CountEvenNumbers style={styles.instructions} count={this.state.count}/>
      </View>
    );
  }
}

export default class App extends Component {
  constructor (props){
    super(props)
    this.state = {
      showCounter: true,
    }
  }


  toggleCounter = () => this.setState(prevState => ({
    showCounter: !prevState.showCounter,
  }))
  render() {
    if (this.state.showCounter){

      return (
        <View style={styles.container}>
            <Button title="toggle" onPress={this.toggleCounter}/>
        <CountEvenNumbers/>

        </View>
        
    );
      }
    else {
      return (
        <View style={styles.container}>
              <Button title="toggle" onPress={this.toggleCounter}/>
              <Counter />
        </View>
      )
    }

    }
    
  }
